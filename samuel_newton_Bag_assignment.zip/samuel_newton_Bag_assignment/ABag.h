#pragma once
#include <iostream>
#include "bagADT.h"

using namespace std;

template <typename E>
class ABag : public Bag<E>					
{
private:
	const static int MAXCAPACITY = 10;			     //setting max capacity of the bag to 10 elements
	int used = 0;									 //creating a variable to keep track of how many times we add element to bag
	E bagarray[MAXCAPACITY];
	
public:
	ABag(){}										 //default constructor 
	~ABag(){}										 //default destructor
	

	bool addItem(const E& item)
	{
		if (used == MAXCAPACITY)					 //checking to see if the bag is already full
		{
			return false;
		}
		else
		{
			bagarray[used] = item;					// adds item to bag, and increments used 
			used++;
			return true;
		}
	}

	bool remove(E& item) 
	{
		bool flag = false;
		for (int x = 0; x < used && flag != true; x++)
		{
			if (bagarray[x] == item)				//checking to see if item exists in bag
			{
				flag = true;
				item = bagarray[x];
				for (; x < used; x++)
				{
				bagarray[x] = bagarray[x + 1];		
				}	
				used--;						       //decrementing used 
			}	
			
			
		}
		return flag;
	}

	bool removeTop(E& returnValue)
	{
		bool flag = false;

		if (used > 0)
		{
			returnValue = bagarray[used - 1];			// removing returnValue at top portion of bag 
			flag = true;	
			used--;										// decrementing used 
		}
		return flag;
	}

	bool find(E& returnValue) const
	{
		bool flag = false;

		for (int i = 0; i < used && flag != true; i++)
		{
			if (bagarray[i] == returnValue) {			//checks to see if object in bag = returnValue & if so will output true
				flag = true;							// & update returnValue
				returnValue = bagarray[i];
			}
		}
		return flag;
	}

	bool inspectTop(E& item) const						
	{
		bool flag = false;
		if (used != 0)
		{
			item = bagarray[used - 1];					//updating item if there exists an object in bag
			flag = true;
		}
		return flag;
	}

	void emptyBag()										//simply sets used to 0 logically clearing bag
	{
		used = 0;
		return;
	}

	bool operator+=(const E& addend)					//same functionailty as addItem
	{
		if (used == MAXCAPACITY)
		{
			return false;
		}
		else
		{
			bagarray[used] = addend;
			used++;
			return true;
		}
	}

	int size() const								//returns used which tracks number of objects in bag
	{
		return used;
	}

	int bagCapacity() const							//returns MAXCAPACITY which was pre-determined to be 10
	{
		return MAXCAPACITY;
	}
};