#include <string>
#include <sstream>
#include <iostream>
#include "ABag.h"
#include "BDictionary.h"

using namespace std;

int main()
{
	//ABag<int> bagtest;
	//bool bagflag, bagflag3;
	//int top;


	//bagflag = bagtest.addItem(15);

	//bagflag = bagtest.addItem(22);

	//bagflag = bagtest+= 11;

	//bagflag = bagtest.addItem(32);

	////bagflag = bagtest.find(11);

	//bagflag3 = bagtest.inspectTop(top);

	////cout << "Find result was " << bagflag2 << endl;

	//cout << "Top item is " << top << endl;

	//cout << "Bag size is " << bagtest.size() << " Bag capacity is " << bagtest.bagCapacity() << endl;
	//
	//bagtest.emptyBag();

	//return 0;
}