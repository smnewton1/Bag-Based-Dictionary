#pragma once
#include <iostream>
#include "ABag.h"
#include "dictionaryADT.h"
#include "kvpair.h"

using namespace std;

template <typename Key, typename E>
class BDictionary : public Dictionary<Key, E>		//inherits Dictionary class
{
private:

	ABag<KVpair<Key,E>> entry;						//creating new bag and KVpair called entry

public:

	BDictionary(){}									 //default constructor
	BDictionary(const size_t size){}                 //default constructor w/size parameter
	~BDictionary(){}								 //default destructor
	

	void clear()
	{
		entry.emptyBag();		
	}

	bool insert(const Key& k, const E& e)				//inserts KVpair into bag
	{
		KVpair<Key, E> kv(k, e);
		bool flag = false;
		if (entry += kv)								//using += operator
		{												//returns true if item KVpair inserts correctly
			flag = true;
		}
		return flag;
	}

	bool remove(const Key& k, E& rtnVal)
	{
		KVpair<Key, E> kv(k, rtnVal);
		bool flag = false; 

		if (entry.remove(kv) == true) {					//removing KV object from bag and if succeeds...	
			rtnVal = kv.value();						// udpates rtnVal to value of KV
			flag = true;								// & sets flag to true.
		}
		return flag;
	}

	bool removeAny(E& returnValue)						
	{
		bool flag = false;
		KVpair<Key, E> kv;

		if (entry.removeTop(kv) == true) {					//seeing if removing the kv object succeeded
			returnValue = kv.value();						//updating returnValue 
			flag = true;
		}
		return flag;
	}

	bool find(const Key& k, E& returnValue) const			
	{
		KVpair<Key, E> kv(k, returnValue);
		bool flag = false;

		if (entry.find(kv) == true) {					//searches for kv value in bag and if found, updates returnValue
			returnValue = kv.value();
			flag = true;
		}
		return flag;
	}

	int size()
	{
		return entry.size();						//simply returns size of dictionary
	}
};